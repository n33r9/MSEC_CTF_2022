#!/usr/bin/env python3

import binascii
from hashlib import md5
import json
import string
from Crypto.Cipher import AES

from os import urandom
from base64 import b64encode , b64decode
from flag import flag


my_secret = "*********" # this is hidden
split_string = b'_thisisstringsplit_'
banner = '''1: login
2: encrypt
3: decrypt
4: get flag
5: exit
'''


BLOCK_SIZE = 16  # Bytes
pad = lambda s: s + (BLOCK_SIZE - len(s) % BLOCK_SIZE) * \
                chr(BLOCK_SIZE - len(s) % BLOCK_SIZE).encode()
unpad = lambda s: s[:-ord(s[len(s) - 1:])]
class AESCipher:
    def __init__(self, key):
        self.key = md5(key.encode('utf8')).hexdigest()

    def encrypt(self, raw):

        raw = pad(raw)
        cipher = AES.new(self.key.encode('utf8'), AES.MODE_ECB)
        return b64encode(cipher.encrypt(raw))

    def decrypt(self, enc):
        enc = b64decode(enc)
        cipher = AES.new(self.key.encode('utf8'), AES.MODE_ECB)
        return unpad(cipher.decrypt(enc))
    

aes_encrypt  = AESCipher(my_secret) 
def make_cookies():
    try:

        account = b64decode(input("Account: ").encode())
        json_cookies = json.loads(account,  strict=False)
        #limit name 15 char
        json_cookies['name'] = json_cookies['name'][:15]
        string_name = json_cookies['name']
        if 'admin' in string_name:
            print("No no!!! You aren't admin!!")
            return
        hash = md5((my_secret + json.dumps(json_cookies)).encode()).hexdigest()
        string_en = account  + split_string+ hash.encode()
        sign = aes_encrypt.encrypt(string_en)
        
        result = {'encrypt': sign.decode()}
        print("Cookies:", b64encode(json.dumps(result).encode()).decode())

    except Exception as e :
        print("Error gen cookies", e)
def encrypt_data():
    try:
        data = b64decode(input("Data: ").encode())
        result = aes_encrypt.encrypt(data)
        print("Result:", result.decode())
    except Exception as e:
        print("Error encrypt:", e)
        
def decrypt_data():
    print("Remove by admin")
    pass
def get_flag():
    try:
        cookies = b64decode(input("Cookies: ").encode())
        json_cookies = json.loads(cookies)
        data_decrypt = aes_encrypt.decrypt(json_cookies['encrypt'].encode())
        data_message = data_decrypt.rsplit(split_string,1)[0]
        data_hash = data_decrypt.rsplit(split_string,1)[1].decode()
        hash = md5(my_secret.encode() + data_message).hexdigest()
        #filter exploit
        data_message = b'{"' + data_message.replace(b'"}', b'').replace(b'{"', b'') + b'"}'
        # json injection
        data_message = data_message.replace(b"'", b'')
        data_message = data_message.decode('utf-8', 'ignore')
        name = json.loads(data_message,  strict=False)['name']
        if data_hash != hash:
            raise Exception("Signature error")
        if name == 'admin':
            print(flag)
        else:
            print("Hello,", name)

    except Exception as e:
        print("Error: ", e)
if __name__ == "__main__":
    print(banner)
    for count in range(1000):
        try:
            option = int(input("Option:"))
            if option == 1:
                make_cookies();
            elif option ==2:
                encrypt_data()
            elif option == 3:
                decrypt_data()
            elif option == 4:
                get_flag();
            elif option == 5:
                print("Bye!!!!!")
                break
            else:
                print("Error option")
        except Exception as e:
            print("Error:", e)
            break
